# Data Directory

This directory contains the input and processed data for the biomass prediction project.

## Structure
