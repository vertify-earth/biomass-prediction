"""
Test suite for biomass prediction pipeline.
"""